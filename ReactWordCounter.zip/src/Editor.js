import React from 'react';

const Editor = ({ text, handleTextChange }) => {
    return (
        <div className="row">
            <div className="input-field col s9">
                <label htmlFor="editor">Enter your text</label>
                <textarea
                    id="editor"
                    type="text"
                    value={text}
                    className="materialize-textarea"
                    onChange={(event) => handleTextChange(event.target.value)}
                ></textarea>
            </div>
        </div>
    );
}

export default Editor;