import React from 'react';
const Counter = ({ count }) => {
    return (
        <div className="row">
            <div className="col s9">
                <label htmlFor="wordcount" >Word Count</label>
                <input
                    id="wordcount"
                    type="text"
                    value={count}
                ></input>
            </div>
        </div>
    );
}

export default Counter;