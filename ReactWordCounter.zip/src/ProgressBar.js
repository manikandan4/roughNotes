import React from 'react';

const ProgressBar = ({ completion }) => {
    const perc = completion * 100;
    return (
        <div className="row">
            <div className="input-field col s9">
                <label htmlFor="progress" >Progress</label>
                <progress value={completion} id="progress" className="col s12">{perc}%</progress>
            </div>
        </div>
    );
}

export default ProgressBar;