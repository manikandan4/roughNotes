import countWords from '../countWord';
describe('Testing the countWords function',() =>{
    it('counts the correct number of words', () => {
        expect(countWords('welcome to reactJS')).toBe(3);
    });
    it('counts an empty string', () => {
        expect(countWords('')).toBe(0);
    });
});

