import React, { useState } from 'react';
import Editor from './Editor';
import Counter from './Counter';
import ProgressBar from './ProgressBar';
import SaveComponent from './SaveComponent'
import countWords from './countWord';

const WordCounter = ({ targetWordToCount }) => {
    const [text, setText] = useState('react');
    const wordCnt = countWords(text);
    const completionVal = wordCnt / targetWordToCount;

    const handleTextChange = (newText) => {
        setText(() => newText);
    }
    const MakeFakeReq = () => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (Math.random() > 0.5) {
                    resolve('Success');
                } else {
                    reject('Failure');
                }
            }, 1000);
        });
    }
    return (
        <div className="card">
            <div className="card-content">
                <form className="col">
                    <Editor text={text} handleTextChange={handleTextChange} />
                    <Counter count={wordCnt} />
                    <ProgressBar completion={completionVal} />
                    <SaveComponent saveFunction={MakeFakeReq} />
                </form>
            </div>
        </div>

    );
}

export default WordCounter;