import React from 'react';
import ReactDOM from 'react-dom';
import WordCounter from './WordCounter';

M.AutoInit();
const Navbar = () => {
    return (
        <nav className="teal z-depth-3">
            <div class="nav-wrapper">
                <a href="#" class=" center brand-logo">Word Counter</a>
            </div>
        </nav>
    );
}

ReactDOM.render(
    <div className="">
        <Navbar />
        <WordCounter targetWordToCount={20} />
    </div>,

    document.getElementById("app")
);
if (module.hot) {
    module.hot.accept();
}