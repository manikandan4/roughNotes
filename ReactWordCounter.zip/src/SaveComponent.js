import React ,{useState} from 'react';
const SUCCESS = 'SUCCESS';
const FAILURE = 'FAILURE';
const WAITING = 'WAITING';
const IDLE = 'IDLE';

const SaveBtn = ({ onclick }) => {
    return (
        <button onClick={onclick} className="waves-effect waves-light btn col s3">Save</button>
    )
}

const ShowStatus = ({ msg }) => {
    let textColor = "blue-text";
    if (msg === FAILURE) {
        textColor = "red-text";
    } else if (msg === WAITING) {
        textColor = "orange-text"
    } else if (msg === SUCCESS) {
        textColor = "green-text"
    }
    textColor = textColor + " col s6";
    if (msg.startsWith(IDLE)) {
        return null;
    } else {
        return (<div className={textColor}>{msg}</div>)
    }
}

const SaveComponent = ({ saveFunction }) => {
    const [msg, setMsg] = useState(IDLE);

    const save = (event) => {
        event.preventDefault();
        setMsg(WAITING);

        saveFunction()
            .then(
                success => setMsg(SUCCESS),
                failure => setMsg(FAILURE)
            );
    }

    return (
        <div className="row">
            <SaveBtn onclick={save} />
            <ShowStatus msg={msg} />
        </div>
    );

}

export default SaveComponent;